public class Main {
    public static void main(String[] args) {
        char letter = 'G';
        int number = 89;
        byte byteNumber = 4;
        short shortNumber = 56;
        float floatNumber = 4.7333436f;
        double doubleNumder =  4.355453532;
        long longNumber = 12121L;
        System.out.println(
                "char: " + letter + "\n"+
                 "int: " + number + "\n"+
                 "byte: " + byteNumber + "\n"+
                "short: " + shortNumber + "\n"+
                "float: " + floatNumber + "\n"+
                 "double: " + doubleNumder + "\n"+
                "long: " + doubleNumder + "\n"
        );

        int number1 = 345;
        System.out.println(number1 / 100);
        System.out.println(number1 / 10 % 10);
        System.out.println(number1 % 10);

        System.out.println();
        
        int number2 = 987;
        System.out.println(number2 / 100);
        System.out.println(number2 / 10 % 10);
        System.out.println(number2 % 10);
    }
}