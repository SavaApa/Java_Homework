package game;

public enum GameElements {
    STONE,
    SCISSORS,
    PAPER
}
