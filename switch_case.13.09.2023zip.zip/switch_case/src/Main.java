import game.GameElements;
import wedding.WeddingAnniversary;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Пользователь вводит, сколько лет он состоит в браке. Программа должна
//вывести, какая годовщина свадьбы будет у пользователя следующей (бумажная,
//ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины,
//достаточно 10-15.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Сколько лет вы в браке");
        int yearsMarriage = scanner.nextInt()+1;
        WeddingAnniversary anniversary = switch (yearsMarriage){
            case 1 -> WeddingAnniversary.СИТЦЕВАЯ;
            case 2 -> WeddingAnniversary.БУМАЖНАЯ;
            case 3 -> WeddingAnniversary.КОЖАНАЯ;
            case 4 -> WeddingAnniversary.ЛЬНЯНАЯ;
            case 5 -> WeddingAnniversary.ДЕРЕВЯННАЯ;
            case 6 -> WeddingAnniversary.ЧУГУННАЯ;
            case 7 -> WeddingAnniversary.МЕДНАЯ;
            case 8 -> WeddingAnniversary.ЖЕСТЯНАЯ;
            case 9 -> WeddingAnniversary.ФАЯНСОВАЯ;
            case 10 -> WeddingAnniversary.ОЛОВЯННАЯ;
            case 11 -> WeddingAnniversary.СТАЛЬНАЯ;
            default -> throw new RuntimeException("Недоступное значение");
        };

        String nextAnniversary = switch (anniversary){
            case СИТЦЕВАЯ -> "Следующая будет СИТЦЕВАЯ";
            case БУМАЖНАЯ -> "Следующая будет БУМАЖНАЯ";
            case КОЖАНАЯ -> "Следующая будет КОЖАНАЯ";
            case ЛЬНЯНАЯ -> "Следующая будет ЛЬНЯНАЯ";
            case ДЕРЕВЯННАЯ -> "Следующая будет ДЕРЕВЯННАЯ";
            case ЧУГУННАЯ -> "Следующая будет ЧУГУННАЯ";
            case МЕДНАЯ -> "Следующая будет МЕДНАЯ";
            case ЖЕСТЯНАЯ -> "Следующая будет ЖЕСТЯНАЯ";
            case ФАЯНСОВАЯ -> "Следующая будет ФАЯНСОВАЯ";
            case ОЛОВЯННАЯ -> "Следующая будет ОЛОВЯННАЯ";
            case СТАЛЬНАЯ -> "Следующая будет СТАЛЬНАЯ";
            default -> throw new RuntimeException("Недопустимое значение планеты");
        };
        System.out.println(nextAnniversary);


//        Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит
//свой выбор (в виде строки или числа). Программа случайным образом делает
//свой выбор и выводит на экран. Далее программа показывает, кто победитель –
//пользователь или программа.
        System.out.println("1: Paper, 2: Stone, 3: Scissors");
       int people = new Scanner(System.in).nextInt();
        GameElements element = switch (people){
            case 1 -> GameElements.PAPER;
            case 2 -> GameElements.STONE;
            case 3 -> GameElements.SCISSORS;
            default -> throw new RuntimeException("Недопустимое значение ");
        };
        System.out.println(element);
        Random rnd = new Random();
        Integer comp = rnd.nextInt(1, 4);
        GameElements elementComp = switch (comp){
            case 1 -> GameElements.PAPER;
            case 2 -> GameElements.STONE;
            case 3 -> GameElements.SCISSORS;
            default -> throw new RuntimeException("Недопустимое значение ");
        };
        System.out.println(elementComp);
        if (comp == people){
            System.out.println("Ничья");
        }else  if (people == 1 && comp == 2){
            System.out.println("Победил пользователь");
        }else  if (people == 2 && comp == 3) {
            System.out.println("Победил пользователь");
        }else  if (people == 3 && comp == 1) {
            System.out.println("Победил пользователь");
        }else{
            System.out.println("Победил компьютер");
        }
    }
}