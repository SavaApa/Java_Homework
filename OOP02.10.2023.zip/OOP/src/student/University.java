package student;

public class University {
        Student savelii = new Student("Savelii");
}
