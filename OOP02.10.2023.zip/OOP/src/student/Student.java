package student;

public class Student {
    public String name;
    private long numberPhone;
    private int age;
    String group;

    public Student(String name){
        this.name = name;
    }

    public long getNumberPhone() {
        return numberPhone;
    }

    public void setNumberPhone(long numberPhone) {
        this.numberPhone = numberPhone;
    }

    public int getAge(){return age;}

    public void setAge(int age){
        if(age < 17){
            throw new IllegalArgumentException("Вы слишком молоды, чтобы быть студентом");
        }
        this.age = age;
    }

    public Student(String name, int age){
        this(name);
        this.age = age;
    }

    public Student(Student original){
        this(original.name, original.age);
    }
}
