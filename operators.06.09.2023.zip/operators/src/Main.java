import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Дана длина в метрах. Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        //Выведите начальное и конвертированные значения на экран.
//        float metr = 20;
//        System.out.println(metr + " метров");
//        System.out.println(metr / 1000 + " километров");
//        System.out.println(metr * 0.00064 + " метров");
//        System.out.println(metr * 3.281 + " футов");
//        System.out.println(metr * 1.406 + " аршин");

        //Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель. Выведите
//        //сумму сдачи в виде “X рублей и Y копеек”.
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Введите суму покупки");
//        double totalСost = scanner.nextDouble();
//        System.out.println("Введите сумму денег");
//        double amountOfMoney = scanner.nextDouble();
//        double changeAmount = amountOfMoney - totalСost;
//        int rubl = (int) changeAmount;
//        double cop = changeAmount * 100 % 100;
//        int copeec = (int)cop;
//        System.out.println(rubl + " рублей " +  copeec + " копеек");

        // Когда закончится учебный год (isYearFinished) и если будет солнечная погода (isGoodWeather), то ребята пойдут
        //в поход. Если туркружок закупит дождевики (hasBoughtRaincoats) к концу учебного года, то ребята пойдут в
        //поход даже в плохую погоду. В поход ребят должен кто-то повести. Поведёт тренер Джим, если он освободится
        //от сдачи тренерского экзамена (isJimFree), или тренер Кейт, если она вернётся из путешествия
        //(hasKateComeBack). Вести детей может только один тренер. Если Джим и Кейт смогут вести детей вместе, то
        //они обязательно поссорятся из-за этого и никто никуда не пойдёт.
       boolean isYearFinished = true;
       boolean isGoodWeather = false;
       boolean hasBoughtRaincoats = false;
       boolean isJimFree = true;
       boolean hasKateComeBack = true;
       boolean hike = (isYearFinished && (isGoodWeather | hasBoughtRaincoats) || isJimFree && hasKateComeBack
                && (isJimFree ^ hasKateComeBack));
        System.out.println(hike);


        //Пользователь вводит целое число. Напишите программу, которая делит это число на 2 и выводит результат.
        //Остаток деления можно отбросить. Операторы деления / и остатка от деления % применять нельзя.
        int number = 5;
        int number1 = number>>1;
        System.out.println(number1);

    }
}
