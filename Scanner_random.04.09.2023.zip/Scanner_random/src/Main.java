import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//         Напишите программу, в которой объявите переменные всех примитивных типов. Значение для каждой
//        переменной сгенерируйте с помощью класса Random. При необходимости используйте приведение типов.
//        Полученные значения выведите в консоль
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt();
        short s = (short) rnd.nextInt();
        int i = rnd.nextInt();
        char c = (char) rnd.nextInt();
        float f = rnd.nextFloat();
        long l = rnd.nextLong();
        double d = rnd.nextDouble();
        boolean bool = rnd.nextBoolean();
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(c);
        System.out.println(f);
        System.out.println(l);
        System.out.println(d);
        System.out.println(bool);
//
//        //2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки. При необходимости
//        //используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет. Полученное значение
//        //выведите в консоль
        Random r = new Random(6);
        String str = String.valueOf(r);
        System.out.println(str);
//
//        //Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес. Когда все данные
//        //введены, программа должна выдать сообщение: «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как
//        //[Вес] килограмм золота.». В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите своё имя");
        String name = scanner.nextLine();
        System.out.println("Введите свой возраст");
        int age = scanner.nextInt();
        System.out.println("Введите свой вес");
        double weight = scanner.nextDouble();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %.1f килограмм золота.", name, age, weight);

        //Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение),
        //разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел. Результат вычисления
        //выведите в консоль
        Scanner scanner1 = new Scanner(System.in);
        System.out.println("Введите первое число");
        int number1 = scanner1.nextInt();
        System.out.println("Введите второе число");
        int number2 = scanner1.nextInt();
        System.out.println(number1 + number2);
        System.out.println(number1 - number2);
        System.out.println(number1 * number2);
        System.out.println(number1 / number2);
    }
}