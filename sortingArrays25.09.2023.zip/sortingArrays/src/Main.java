import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
//        1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
//Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день), где год,
//месяц и день – целые числа.
//Выведите массив в консоль
//  2.Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
//        3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в
//консоль


        LocalDate[] date = {
                LocalDate.of(1989, 8, 14),
                LocalDate.of(2000, 7, 16),
                LocalDate.of(1978, 9, 17),
                LocalDate.of(1989, 12, 9),
                LocalDate.of(1978, 7, 19),
                LocalDate.of(1971, 2, 1),
                LocalDate.of(1990, 1, 7),
                LocalDate.of(1999, 4, 18),
        };
        System.out.println(Arrays.toString(date));
        sortByYear(date);
        System.out.println(Arrays.toString(date));
        sortByDay(date);
        System.out.println(Arrays.toString(date));
        makeAlphabet(6);
        System.out.println(Arrays.deepToString(makeAlphabet(6)));
    }

    private static void sortByYear(LocalDate[] date) {
        boolean isSorted = false;
        LocalDate buf;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < date.length - 1; i++) {
                if (date[i].getYear() > date[i + 1].getYear()) {
                    isSorted = false;
                    buf = date[i];
                    date[i] = date[i + 1];
                    date[i + 1] = buf;
                }
            }
        }
    }
    private static void sortByDay(LocalDate[] date) {
        boolean isSorted = false;
        LocalDate buf;
        while (!isSorted) {
            isSorted = true;
            for (int i = 0; i < date.length - 1; i++) {
                if (date[i].getDayOfMonth() > date[i + 1].getDayOfMonth()) {
                    isSorted = false;
                    buf = date[i];
                    date[i] = date[i + 1];
                    date[i + 1] = buf;
                }
            }
        }
    }

//    

    private static char[][] makeAlphabet(int size) {
        char[][] array = new char[size][size];
        char letter = 'А';
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[i][j] = letter;
                letter++;
                if (letter > 'Я') break;
                if (letter == 'Ж') {
                    if (j == array[i].length - 1) {
                        i++;
                        j = 0;
                    } else {
                        j++;
                    }
                    array[i][j] = 'Ё';
                }
            }
        }
        return array;
    }
}
