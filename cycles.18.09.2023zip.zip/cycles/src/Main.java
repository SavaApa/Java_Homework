import java.time.DayOfWeek;
import java.time.Month;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//   Напиши программу, которая моделирует ситуацию.
//Ты попросил(а) друзей скинуться на подарок на твой День Рождения. Каждый друг случайным образом
//может подарить тебе одну купюру номиналом 50, 100, 200 или 500 долларов. Твоя цель - новенький игровой
//компьютер, который стоит 10 000 долларов.
//Как только друзья подарят тебе нужную сумму (или даже чуть больше), останавливай сбор подарков и веди
//всех выпить за твоё здоровье в лучший бар города!
//        Random rnd = new Random();
//        int sum = 0;
//        do {
//            int number = rnd.nextInt(4);
//            int dollar = switch (number) {
//                case 0 -> 50;
//                case 1 -> 100;
//                case 2 -> 200;
//                case 3 -> 500;
//                default -> 0;
//            };
//            sum += dollar;
//        }while (sum < 10_000);
//        System.out.println(sum);
//
////       Используйте for для вычисления суммы.
////Используйте do-while для организации повторения программы.
////Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем. Программу
////повторять, пока пользователь не введёт «quit».
//
//        Scanner scanner = new Scanner(System.in);
//        int numSum = scanner.nextInt();
//        int numSum2 = scanner.nextInt();scanner.nextLine();
//        String str = "";
//        do {
//            for (int i = numSum; i <= numSum2; i++) {
//                if (i % 2 != 0) {
//                    sum += i;
//                }
//            }
//            System.out.println(sum);
//            System.out.println("Введите quit для выхода");
//            str = scanner.nextLine();
//        }while (!"quit".equalsIgnoreCase(str));


        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль. Программа должна вывести все
        //дни недели, кроме данного.
        Scanner scanner1 = new Scanner(System.in);
        String str1 = scanner1.nextLine();
        for (DayOfWeek m : DayOfWeek.values()) {
            if (Objects.equals(str1, "Monday")) {
                if (m.equals(DayOfWeek.MONDAY)) continue;
                System.out.println(m);
            } else if (Objects.equals(str1, "Tuesday")) {
                if (m.equals(DayOfWeek.TUESDAY)) continue;
                System.out.println(m);
            }else if (Objects.equals(str1, "Wednesday")) {
                if (m.equals(DayOfWeek.WEDNESDAY)) continue;
                System.out.println(m);
            }else if (Objects.equals(str1, "Thursday")) {
                if (m.equals(DayOfWeek.THURSDAY)) continue;
                System.out.println(m);
            }else if (Objects.equals(str1, "Friday")) {
                if (m.equals(DayOfWeek.FRIDAY)) continue;
                System.out.println(m);
            }else if (Objects.equals(str1, "Saturday")) {
                if (m.equals(DayOfWeek.SATURDAY)) continue;
                System.out.println(m);
            }else if (Objects.equals(str1, "Sunday")) {
                if (m.equals(DayOfWeek.SUNDAY)) continue;
                System.out.println(m);
            }else{
                System.out.println("Такого дня недели нету");
            }

        }

    }
}


