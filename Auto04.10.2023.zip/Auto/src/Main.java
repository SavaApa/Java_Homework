import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Auto suzuki = new Auto("Suzuki", "Vitara", 3.4, "газ", 400);
        System.out.println(suzuki);

        Auto mercedes = new Auto("Мерседес", "Майбах", 5.0, "бензин", 500);
        System.out.println(mercedes);

        Auto bmv = new Auto("BMV", "X5", 5, ",бензин", 460);
        System.out.println(bmv);
        System.out.println();

        Auto[] auto = {suzuki, mercedes, bmv};
        Arrays.toString(auto);
        System.out.println(Arrays.toString(auto));
        
    }
}
//No2
//Напишите класс Автомобиль с минимум пятью полями.
// Переопределите метод toString, чтобы он выводил полное описание автомобиля по его полям.
// В программе создайте 3 разных автомобиля и выведите каждый из них в консоль.
//Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите массив в строку и выведите в консоль.
//Перейдите в код метода Arrays.toString() и посмотрите на его реализацию.
// В какой момент автомобиль становится строкой внутри этого метода?