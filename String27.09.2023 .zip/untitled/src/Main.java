import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв
//(проверьте количество букв в слове).
//Нужно получить слово, состоящее из первой половины первого слова и второй половины
//второго слова. распечатать на консоль.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое слово");
        String strOne = scanner.nextLine();
        System.out.println("Введите второе слово");
        String strTwo = scanner.nextLine();
        if (strOne.length() % 2 == 0 && strTwo.length() % 2 == 0){
            String str3 = (strOne.substring(0, strOne.length()/2)) +
                    (strTwo.substring(strTwo.length()/2, strTwo.length()));
            System.out.println(str3);
        }else{
            System.out.println("Введите другое слово");
        }
        String str1 = new String("I study Basic Java!");
        String(str1);
        System.out.println(str1);
        System.out.println(str1.charAt(str1.length() - 1));
        System.out.println(str1.contains("Java"));
        System.out.println(str1.replace("a", "o"));
        System.out.println(str1.replace("a", "o"));
        System.out.println(str1.toUpperCase(Locale.ROOT));
        System.out.println(str1.toLowerCase(Locale.ROOT));
        System.out.println(str1.replace("Java", ""));

    }

    private static void String(String str){
    }

//    Задание из собеседования Яндекс:
//дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов
//латинского алфавита. Напишите метод, который «свернёт» строку к виду
//A4B3C3D2EG, т.е. количество букв записывается цифрой. Если буква одна, то цифра
//не ставится.

}
