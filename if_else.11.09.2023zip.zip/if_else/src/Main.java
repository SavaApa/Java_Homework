import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Создать программу, выводящую на экран ближайшее к 10 из двух чисел,
        //записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Введите первое число");
//        int number1 = scanner.nextInt();
//        System.out.println("Введите второе число");
//        int number2 = scanner.nextInt();
//        if (Math.abs(number1 - 10) > Math.abs(number2 - 10)){
//            System.out.println(number2);
//        }else{
//            System.out.println(number1);
//        }

        //Необходимо написать программу, которая проверяет пользователя на знание
        //таблицы умножения. Пользователь сам вводит два целых однозначных числа.
        //Программа задаёт вопрос: результат умножения первого числа на второе.
        //Пользователь должен ввести ответ и увидеть на экране правильно он ответил
        //или нет. Если пользователь ответил неправильно, то программа должна
        //показать правильный ответ
//        Scanner scr = new Scanner(System.in);
//        System.out.println("Введите первое число");
//        int num1 = scanner.nextInt();
//        System.out.println("Введите второе число");
//        int num2 = scanner.nextInt();
//        System.out.println("Результат умножения первого числа на второе");
//        int result = scanner.nextInt();
//        if (result == num1 * num2){
//            System.out.println(result + " Это правильный ответ");
//        }else{
//            System.out.println(num1 * num2 + " Вот это правильный ответ");
//        }
        //Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите
        //программу, в которой пользователь вводит год. Если указанный год меньше 1935, то
        //вывести «Элвис ещё не родился». Если указанный пользователем год с 1935 по 1977
        //включительно, то вывести «Элвис жив!». Если введённый пользователем год больше 1977,
        //то вывести «Элвис навсегда в наших сердцах!»
        Scanner scann = new Scanner(System.in);
        System.out.println("Введите год");
        int year = scann.nextInt();
        System.out.println(1935 > year ? "Элвис ещё не родился" : "" );
        System.out.println(1935 <= year && year <= 1977 ? "Элвис жив!" : "" );
    }
}