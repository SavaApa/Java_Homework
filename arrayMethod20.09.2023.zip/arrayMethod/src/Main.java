import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
//        1. Создайте массив из 8 случайных целых чисел из интервала [1;50]
//2. Выведите массив на консоль в строку.
//3. Замените каждый элемент с нечетным индексом на ноль.
//4. Снова выведете массив на консоль в отдельной строке.
//5. Отсортируйте массив по возрастанию.
//6. Снова выведете массив на консоль в отдельной строке
        Random rnd = new Random();
        int[] array = new int[8];
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1, 51);
            System.out.println(array[i]);
        }
        System.out.println(" ");

        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1, 51);
            if (i % 2 == 0) {
                array[i] = 0;
            }
            System.out.println(array[i]);
        }
        System.out.println(" ");

        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1, 51);
        }
        Arrays.sort(array);
        for (int arr : array) {
            System.out.println(arr);
        }
        System.out.println(" ");

//        1. Создайте массив из 5 строк. Используя метод length() строк,
//найдите строку с наибольшей длиной и строк с наименьшей
//длиной.
//2. Выведите массив и полученный строки в консоль.
        String[] str = {"Maksim", "Computer", "IPhone", "Apple", "Windows"};
        String elem0 = str[0];
        String elem1 = str[1];
        String elem2 = str[2];
        String elem3 = str[3];
        String elem4 = str[4];
        int max = Math.max(elem0.length(), elem1.length());
        int max1 = Math.max(max, elem2.length());
        int max2 = Math.max(max1, elem3.length());
        int max3 = Math.max(max2, elem4.length());
        System.out.println(max3);
        int min = Math.min(elem0.length(), elem1.length());
        int min1 = Math.min(min, elem2.length());
        int min2 = Math.min(min1, elem3.length());
        int min3 = Math.min(min2, elem4.length());
        System.out.println(min3);

        //        Задание 1.
//Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х
//чисел. В методе умножения 3-х чисел используйте вызов метода для
//2-х чисел. В методе умножения 4-х чисел – вызов метода для 3-х
//чисел.
        System.out.println(multiplication(2,3,4,3));
        System.out.println(facorial(5));
    }
        public static int multiplication(int num1, int num2){
            return num1 * num2;
        }
        public static int multiplication(int num1, int num2, int num3){
            return multiplication(num1, num2) * num3;
    }
        public static int multiplication(int num1, int num2, int num3, int num4) {
        return multiplication(num1, num2, num3) * num4;
    }
//Используя рекурсию, написать метод вычисления факториала числа n
//(n!), вводимого с клавиатуры.
    private static int facorial(int f){
        int result = 1;
        if(f == 1 || f == 0){
            return result;
        }
        result = f * (facorial(f - 1));
        return result;
    }
}

